export function Menu() {
    return (
        <></>
    );
}