export const temaClaro = {
    primero: '#2A7AE4',
    oscuro: '#191919',
    semioscuro: '#5C5C5C',
    oscuroligero: '#C2C2C2',
    texto: '#FFFFFF',
    h1: '1.5rem'
}