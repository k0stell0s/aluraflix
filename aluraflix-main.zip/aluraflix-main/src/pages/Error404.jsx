export function Error404() {
    return (
        <>Error 404</>
    );
}